#include "PioneerLibrary.h"

PioneerLibrary::PioneerLibrary() 
{
      //Anything you might need when instantiating your object goes here
  
}

//Example function
long PioneerLibrary::Example()
{
//  long specialNumber = random(5, 1000);
  long specialNumber = random();
  specialNumber *= PI;
  specialNumber -= 5;
  return specialNumber;
}


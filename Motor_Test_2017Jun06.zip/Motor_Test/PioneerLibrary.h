//#ifndef PioneerLibrary
//#define PioneerLibrary

#include "Arduino.h"
//#if (ARDUINO >= 100)
//  #include "Arduino.h"
//#else
//  #include "WProgram.h"
//#endif

class PioneerLibrary
{
  public:
    //Constructor
    PioneerLibrary();

    //Method
    long Example();

  private:
    
};
//#endif

